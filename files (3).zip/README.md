# 🎬 Discord Video Bot

Bot Discord contrôlable depuis une interface web. Il télécharge des vidéos depuis +1000 sites (YouTube, TikTok, Twitter, Instagram…) et les envoie directement dans un salon Discord.

---

## 🚀 Installation

### 1. Prérequis

- [Node.js 18+](https://nodejs.org)
- [Python 3.8+](https://python.org) (pour yt-dlp)
- [FFmpeg](https://ffmpeg.org/download.html) (pour fusionner audio+vidéo)

### 2. Installer yt-dlp

```bash
pip install yt-dlp
# ou sur Windows :
winget install yt-dlp
```

Vérifier que ça marche :
```bash
yt-dlp --version
```

### 3. Installer FFmpeg

- **Windows** : https://ffmpeg.org/download.html → ajouter au PATH
- **macOS** : `brew install ffmpeg`
- **Linux** : `sudo apt install ffmpeg`

### 4. Créer le bot Discord

1. Va sur https://discord.com/developers/applications
2. **New Application** → donne un nom
3. Onglet **Bot** → **Add Bot** → copie le **Token**
4. Onglet **OAuth2 > URL Generator** :
   - Coche `bot`
   - Permissions : `Send Messages`, `Attach Files`, `View Channels`
5. Copie le lien généré et ouvre-le pour inviter le bot sur ton serveur

### 5. Configurer et lancer

```bash
# Cloner / copier le projet
cd discord-video-bot

# Installer les dépendances Node
npm install

# Lancer avec ton token Discord
DISCORD_TOKEN=ton_token_ici node server.js

# Ou sur Windows (PowerShell) :
$env:DISCORD_TOKEN="ton_token_ici"; node server.js
```

Le serveur démarre sur **http://localhost:3000**

---

## 🎛️ Utilisation

1. Ouvre **http://localhost:3000** dans ton navigateur
2. Sélectionne le(s) **site(s) source** (YouTube, TikTok, etc.)
3. Colle une ou plusieurs **URLs**
4. Choisis le **salon Discord** de destination
5. Clique sur **Envoyer** 🚀

### Modes disponibles

| Mode | Description |
|------|-------------|
| **URL directe** | Colle 1 ou plusieurs URLs, une par une ou en bloc |
| **Page entière** | Donne une page web, le bot extrait toutes les vidéos trouvées |

---

## ⚙️ Configuration avancée

Dans `server.js`, modifie la section `CONFIG` :

```js
const CONFIG = {
  DISCORD_TOKEN: 'ton_token',   // ou via variable d'environnement
  PORT: 3000,                   // port de l'interface web
  MAX_FILE_SIZE_MB: 25,         // 25 Mo sans Nitro, 500 Mo avec Nitro
  YTDLP_PATH: 'yt-dlp',         // chemin vers yt-dlp si non dans le PATH
};
```

### Limite de taille Discord

| Compte | Limite upload |
|--------|--------------|
| Gratuit | 25 Mo |
| Nitro Basic | 50 Mo |
| Nitro | 500 Mo |

Si la vidéo dépasse la limite, le bot envoie le lien direct à la place.

---

## 🌐 Sites supportés

yt-dlp supporte **+1000 sites** dont :
YouTube, TikTok, Twitter/X, Instagram, Facebook, Twitch, Reddit, Dailymotion, Vimeo, Bilibili, Rumble, SoundCloud, Bandcamp, Niconico, 9GAG, et bien d'autres.

Liste complète : https://github.com/yt-dlp/yt-dlp/blob/master/supportedsites.md

---

## 🛠️ Structure des fichiers

```
discord-video-bot/
├── server.js          ← API Express + Bot Discord
├── package.json
├── public/
│   └── index.html     ← Interface web de contrôle
├── downloads/         ← Dossier temporaire (auto-créé)
└── README.md
```

---

## ❓ FAQ

**Le bot ne se connecte pas ?**
→ Vérifie que le token Discord est correct et que le bot est bien invité sur ton serveur.

**yt-dlp: command not found ?**
→ Assure-toi que yt-dlp est installé et dans le PATH. Essaie `python -m yt_dlp` et mets ce chemin dans `YTDLP_PATH`.

**La vidéo est trop lourde ?**
→ Le bot envoie le lien à la place. Tu peux réduire la qualité en modifiant le paramètre `--format` dans `server.js`.

**Je veux que ça tourne en permanence ?**
→ Utilise [PM2](https://pm2.keymetrics.io/) : `npm install -g pm2 && pm2 start server.js`
