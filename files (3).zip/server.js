// server.js — Serveur principal : API Express + Bot Discord
const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const { execFile } = require('child_process');
const { Client, GatewayIntentBits, AttachmentBuilder } = require('discord.js');
const { v4: uuidv4 } = require('uuid');

// ── Configuration ──────────────────────────────────────────────────────────
const CONFIG = {
  DISCORD_TOKEN: process.env.DISCORD_TOKEN || 'METS_TON_TOKEN_ICI',
  PORT: process.env.PORT || 3000,
  MAX_FILE_SIZE_MB: 25,         // Limite Discord sans Nitro (25 Mo)
  DOWNLOAD_DIR: path.join(__dirname, 'downloads'),
  YTDLP_PATH: 'yt-dlp',         // doit être installé : pip install yt-dlp
};

// ── Init ──────────────────────────────────────────────────────────────────
if (!fs.existsSync(CONFIG.DOWNLOAD_DIR)) fs.mkdirSync(CONFIG.DOWNLOAD_DIR, { recursive: true });

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// File de tâches en mémoire
const queue = [];        // { id, url, channelId, status, message, addedAt }
let isProcessing = false;

// ── Client Discord ─────────────────────────────────────────────────────────
const discord = new Client({ intents: [GatewayIntentBits.Guilds] });

discord.once('ready', () => {
  console.log(`✅ Bot connecté : ${discord.user.tag}`);
});

discord.login(CONFIG.DISCORD_TOKEN).catch(err => {
  console.error('❌ Erreur connexion Discord :', err.message);
});

// ── Helpers ────────────────────────────────────────────────────────────────

/** Retourne la liste des salons texte de tous les serveurs */
function getTextChannels() {
  const channels = [];
  discord.guilds.cache.forEach(guild => {
    guild.channels.cache
      .filter(c => c.isTextBased() && c.viewable)
      .forEach(c => channels.push({ id: c.id, name: `${guild.name} › #${c.name}` }));
  });
  return channels;
}

/** Télécharge une vidéo avec yt-dlp */
function downloadVideo(url) {
  return new Promise((resolve, reject) => {
    const outTemplate = path.join(CONFIG.DOWNLOAD_DIR, `%(id)s.%(ext)s`);
    const args = [
      url,
      '-o', outTemplate,
      '--no-playlist',
      '--merge-output-format', 'mp4',
      // Limite la taille pour rester sous la limite Discord
      '--max-filesize', `${CONFIG.MAX_FILE_SIZE_MB}M`,
      '--format', `bestvideo[filesize<${CONFIG.MAX_FILE_SIZE_MB}M][ext=mp4]+bestaudio[ext=m4a]/best[filesize<${CONFIG.MAX_FILE_SIZE_MB}M][ext=mp4]/best`,
      '--print', 'after_move:filepath',
    ];

    execFile(CONFIG.YTDLP_PATH, args, (err, stdout, stderr) => {
      if (err) return reject(new Error(stderr || err.message));
      const filepath = stdout.trim().split('\n').pop();
      if (!filepath || !fs.existsSync(filepath)) return reject(new Error('Fichier introuvable après téléchargement'));
      resolve(filepath);
    });
  });
}

/** Envoie la vidéo (ou le lien si trop lourde) sur Discord */
async function sendToDiscord(channelId, url, message) {
  const channel = await discord.channels.fetch(channelId);
  if (!channel) throw new Error('Salon introuvable');

  let filepath;
  try {
    filepath = await downloadVideo(url);
    const stat = fs.statSync(filepath);
    const sizeMB = stat.size / 1024 / 1024;

    if (sizeMB > CONFIG.MAX_FILE_SIZE_MB) {
      // Fichier trop lourd → envoyer le lien direct
      await channel.send({ content: `${message ? message + '\n' : ''}🎥 ${url}\n⚠️ Vidéo trop lourde pour être uploadée (${sizeMB.toFixed(1)} Mo)` });
    } else {
      const attachment = new AttachmentBuilder(filepath);
      await channel.send({ content: message || undefined, files: [attachment] });
    }
  } finally {
    // Nettoyage du fichier temporaire
    if (filepath && fs.existsSync(filepath)) {
      fs.unlink(filepath, () => {});
    }
  }
}

// ── Traitement de la file ──────────────────────────────────────────────────
async function processQueue() {
  if (isProcessing) return;
  const task = queue.find(t => t.status === 'pending');
  if (!task) return;

  isProcessing = true;
  task.status = 'processing';
  task.startedAt = new Date().toISOString();

  try {
    await sendToDiscord(task.channelId, task.url, task.message);
    task.status = 'done';
    task.finishedAt = new Date().toISOString();
  } catch (err) {
    task.status = 'error';
    task.error = err.message;
    task.finishedAt = new Date().toISOString();
    console.error('❌ Erreur tâche', task.id, ':', err.message);
  } finally {
    isProcessing = false;
    // Traiter la tâche suivante
    setTimeout(processQueue, 500);
  }
}

// ── Routes API ─────────────────────────────────────────────────────────────

// Statut du bot
app.get('/api/status', (req, res) => {
  res.json({
    online: discord.isReady(),
    botName: discord.user?.tag || null,
    queueLength: queue.filter(t => t.status === 'pending').length,
  });
});

// Liste des salons disponibles
app.get('/api/channels', (req, res) => {
  if (!discord.isReady()) return res.status(503).json({ error: 'Bot non connecté' });
  res.json(getTextChannels());
});

// Ajouter une vidéo à la file
app.post('/api/send', (req, res) => {
  const { url, channelId, message } = req.body;
  if (!url || !channelId) return res.status(400).json({ error: 'url et channelId requis' });

  const task = {
    id: uuidv4(),
    url,
    channelId,
    message: message || '',
    status: 'pending',
    addedAt: new Date().toISOString(),
  };
  queue.push(task);
  processQueue();
  res.json({ ok: true, taskId: task.id });
});

// État de la file (toutes les tâches)
app.get('/api/queue', (req, res) => {
  res.json(queue.slice(-50).reverse()); // 50 dernières, les plus récentes en premier
});

// Supprimer une tâche pending
app.delete('/api/queue/:id', (req, res) => {
  const idx = queue.findIndex(t => t.id === req.params.id && t.status === 'pending');
  if (idx === -1) return res.status(404).json({ error: 'Tâche introuvable ou déjà traitée' });
  queue.splice(idx, 1);
  res.json({ ok: true });
});

// ── Démarrage serveur ──────────────────────────────────────────────────────
app.listen(CONFIG.PORT, () => {
  console.log(`🌐 Interface web : http://localhost:${CONFIG.PORT}`);
  console.log(`📋 Token Discord : ${CONFIG.DISCORD_TOKEN === 'METS_TON_TOKEN_ICI' ? '⚠️  À configurer !' : '✅ Défini'}`);
});
